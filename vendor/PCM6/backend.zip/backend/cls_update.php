<?php
require_once("DB_connect.php");
class update
{
    public $complaint_id;
    public $status;
    public function ComplaintStatus()
    {
        $conn = dbconnection();

        $sql = "UPDATE `complaint` SET `status`='$this->status' WHERE `complaint_id`='$this->complaint_id'";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            return true;
        } else {
            return false;
        }
    }
}
