<?php
session_start();
if (isset($_POST['change_status'])) {

    $status=$_POST['status'];

    require_once("cls_update.php");

    $obj = new update();
    $obj->complaint_id = $_SESSION['complaint_id'];
    $obj->status = $status;
   
    $result = $obj->ComplaintStatus();


    if ($result == true) {
        unset($_SESSION['complaint_id']);
        header('Location:../pages/view_complaints.php');
    } else {
        header('Location:../error/error-500.php');
    }
}
else{
    header('Location:../error/error-404.php');
}
?>
